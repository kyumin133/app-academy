export const fetchTodosUtil = () => {
  return $.ajax ({
    url: "api/todos",
    type: "GET",
    success: (response) => {
      // console.log(response);
      return response;
    }
  });
};


export const createTodoUtil = (todo) => {
  return $.ajax ({
    url: "api/todos",
    type: "POST",
    data: { todo },
    success: (response) => {
      // console.log(response);
      return response;
    }
  });
};
