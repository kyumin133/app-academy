export const uniqueId = function() {
  return new Date().getTime();
};
