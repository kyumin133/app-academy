export const RECEIVE_TODOS = "RECIEVE_TODOS";
export const RECEIVE_TODO = "RECIEVE_TODO";
export const REMOVE_TODO = "REMOVE_TODO";
import { fetchTodosUtil, createTodoUtil } from '../util/todo_api_util';

export const fetchTodos = function() {
  return (dispatch) => {
    fetchTodosUtil().then((response) => {
      return dispatch(receiveTodos(response));
    });
  };
};


export const createTodo = function(todo) {
  // console.log(todo);
  return (dispatch) => {
    // console.log(createTodoUtil(todo));
    createTodoUtil(todo).then((response) => {
      return dispatch(receiveTodo(response));
    });
  };
};


export const receiveTodos = function(todos) {
  return {
    type: RECEIVE_TODOS,
    todos: todos
  };
};

export const receiveTodo = function(todo) {
  return {
    type: RECEIVE_TODO,
    todo: todo
  };
};

export const removeTodo = function(todo) {
  return {
    type: REMOVE_TODO,
    todo: todo
  };
};
